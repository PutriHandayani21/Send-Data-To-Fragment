package com.example.senddatatofragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.example.senddatatofragment.R;
import com.example.senddatatofragment.SharedViewModel;
public class FragmentB extends Fragment {

    private SharedViewModel sharedViewModel;
    private TextView productName, productDescription, productPrice;
    private Button sizeS, sizeM, sizeL;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_b, container, false);

        // Inisialisasi ViewModel
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        // Inisialisasi Views
        productName = view.findViewById(R.id.productName);
        productDescription = view.findViewById(R.id.productDescription);
        productPrice = view.findViewById(R.id.productPrice);
        sizeS = view.findViewById(R.id.sizeS);
        sizeM = view.findViewById(R.id.sizeM);
        sizeL = view.findViewById(R.id.sizeL);

        // Mengamati produk yang dipilih
        sharedViewModel.getSelectedProduct().observe(getViewLifecycleOwner(), product -> {
            if (product != null) {
                productName.setText(product.getName());
                productDescription.setText(product.getDescription());
                productPrice.setText("Rp " + product.getPrice());
            }
        });

        return view;
    }
}