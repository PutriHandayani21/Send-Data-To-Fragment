package com.example.senddatatofragment;

import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

public class FragmentA extends Fragment {

    private SharedViewModel sharedViewModel;
    private RecyclerView recyclerView;
    private ProductAdapter adapter;
    private List<Product> productList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_a, container, false);

        // Inisialisasi ViewModel
        sharedViewModel = new ViewModelProvider(requireActivity()).get(SharedViewModel.class);

        // Membuat daftar produk
        productList = new ArrayList<>();
        productList.add(new Product("Baju", "Baju kasual katun nyaman tersedia dalam berbagai ukuran", 100000));
        productList.add(new Product("Jacket", "Jaket kulit sintetis hangat ideal untuk cuaca dingin dan gaya modern", 250000));
        productList.add(new Product("Jeans", "Jeans slim-fit denim elastis, nyaman dan cocok untuk gaya kasual", 150000));

        // Setup RecyclerView
        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new ProductAdapter(productList, product -> {
            sharedViewModel.selectProduct(product); // Mengirim data produk ke ViewModel
            loadFragmentB(); // Memuat FragmentB
        });
        recyclerView.setAdapter(adapter);

        return view;
    }

    // Method untuk memuat FragmentB
    private void loadFragmentB() {
        FragmentB fragmentB = new FragmentB();
        // Memanggil activity untuk memuat FragmentB
        ((MainActivity) getActivity()).loadFragment(fragmentB);
    }
}
